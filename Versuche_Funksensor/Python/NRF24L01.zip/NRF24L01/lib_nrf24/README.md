lib_nrf24
=========

## May 2018 - This is no longer being maintained by the original author.
## Please feel free to fork, copy, adapt if you find it useable

Python2/3 library for NRF24L01+ Transceivers

V0.3 beta

For Raspberry Pi and virtual-GPIO.
NRF24: strictly 3.3V supply!! Although logic pins are 5V tolerant.

This is BETA only so far.
Everything has worked earlier, send, receive, including two RF24 on one host, and including RPI, virtual-GPIO and regular arduino sketch, all talking to each other.

But recent testing has been only LIBRARY plus "example-nrf24-pair.py" on virtual-GPIO, so other parts are yet to be re-verified. 
